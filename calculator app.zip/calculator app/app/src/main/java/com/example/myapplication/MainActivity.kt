package com.example.calculator

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Load InputFragment first
        supportFragmentManager.beginTransaction()
            .replace(R.id.input_container, InputFragment())
            .commit()
    }

    // ---------- Input Fragment ----------
    class InputFragment : Fragment() {
        private lateinit var num1: EditText
        private lateinit var num2: EditText
        private lateinit var addBtn: Button
        private lateinit var subBtn: Button
        private lateinit var mulBtn: Button
        private lateinit var divBtn: Button

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            val view = inflater.inflate(R.layout.fragment_input, container, false)

            num1 = view.findViewById(R.id.editNum1)
            num2 = view.findViewById(R.id.editNum2)
            addBtn = view.findViewById(R.id.btnAdd)
            subBtn = view.findViewById(R.id.btnSub)
            mulBtn = view.findViewById(R.id.btnMul)
            divBtn = view.findViewById(R.id.btnDiv)

            val listener = View.OnClickListener { v ->
                val a = num1.text.toString().toDoubleOrNull() ?: 0.0
                val b = num2.text.toString().toDoubleOrNull() ?: 0.0
                val result = when (v.id) {
                    R.id.btnAdd -> a + b
                    R.id.btnSub -> a - b
                    R.id.btnMul -> a * b
                    R.id.btnDiv -> if (b != 0.0) a / b else Double.NaN
                    else -> 0.0
                }

                val bundle = Bundle()
                bundle.putString("result", result.toString())

                val resultFragment = ResultFragment()
                resultFragment.arguments = bundle

                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.result_container, resultFragment)
                    .commit()
            }

            addBtn.setOnClickListener(listener)
            subBtn.setOnClickListener(listener)
            mulBtn.setOnClickListener(listener)
            divBtn.setOnClickListener(listener)

            return view
        }
    }

    // ---------- Result Fragment ----------
    class ResultFragment : Fragment() {
        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            val view = inflater.inflate(R.layout.fragment_result, container, false)
            val resultText: TextView = view.findViewById(R.id.txtResult)

            val result = arguments?.getString("result") ?: "No Result"
            resultText.text = result

            return view
        }
    }
}

